package com.blood.donor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DonorApplication {
	public static void main(String[] args) {
		SpringApplication.run(DonorApplication.class, args);
	}
}