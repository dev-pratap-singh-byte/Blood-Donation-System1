package com.blood.donor.entity;

public class Donor {
}
