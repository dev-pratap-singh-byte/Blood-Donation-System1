package com.blood.donor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DonorApplicationTests {

	@Test
	void contextLoads() {
	}

}
